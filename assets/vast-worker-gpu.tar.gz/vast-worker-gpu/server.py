# -*- coding: utf-8 -*-
"""
VAST.AI DEDICATED GPU WORKER SERVER
Tích hợp:
1. Voice AI TTS (ViệNeu-TTS) chạy trực tiếp trên GPU CUDA (1-2s/câu).
2. FFmpeg Video Render phần cứng NVIDIA NVENC (h264_nvenc) siêu tốc.
3. Tự động đồng bộ Audio/Video lên Cloudflare R2 CDN.
"""

import os
import sys
import uuid
import time
import shutil
import tempfile
import urllib.request
import subprocess
import re
import math
import boto3
import requests
import torch
from typing import Optional, List, Dict, Any
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from PIL import Image, ImageDraw, ImageFont

try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
except Exception:
    pass

app = FastAPI(title="Vast.ai Dedicated GPU Worker", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# -------------------------------------------------------------
# 1. HARDWARE & ENCODER SETUP
# -------------------------------------------------------------
cuda_available = torch.cuda.is_available()
device_name = torch.cuda.get_device_name(0) if cuda_available else "CPU"
print(f"🚀 [Vast GPU] Hardware: {device_name} (CUDA Available: {cuda_available})")

FFMPEG_BIN = "/usr/bin/ffmpeg" if os.path.exists("/usr/bin/ffmpeg") else "ffmpeg"
FFPROBE_BIN = "/usr/bin/ffprobe" if os.path.exists("/usr/bin/ffprobe") else "ffprobe"

def get_nvenc_encoder_flags():
    try:
        test_cmd = [
            FFMPEG_BIN, "-y",
            "-f", "lavfi", "-i", "color=c=black:s=256x256:d=0.1",
            "-c:v", "h264_nvenc",
            "-f", "null", "-"
        ]
        res = subprocess.run(test_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=5)
        if res.returncode == 0:
            print("⚡ [FFmpeg] NVIDIA NVENC phần cứng sẵn sàng! Tăng tốc render video 10x.")
            return ["-c:v", "h264_nvenc", "-preset", "p4", "-cq", "24"]
    except Exception as e:
        print(f"⚠️ NVENC check error: {e}")
    
    print("ℹ️ [FFmpeg] Sử dụng CPU libx264 ultrafast.")
    return ["-c:v", "libx264", "-preset", "ultrafast"]

ENCODER_FLAGS = get_nvenc_encoder_flags()

# -------------------------------------------------------------
# 2. FONTS SETUP
# -------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FONTS_DIR = os.path.join(BASE_DIR, "fonts")
if not os.path.exists(FONTS_DIR):
    FONTS_DIR = "/workspace/fonts"

def get_font_file(name: str, fallback="DejaVuSans.ttf") -> str:
    fpath = os.path.join(FONTS_DIR, name)
    if os.path.exists(fpath):
        return fpath
    return fallback

# -------------------------------------------------------------
# 3. VIENEU TTS MODEL PRELOAD
# -------------------------------------------------------------
tts = None
tts_init_error = ""

try:
    print(f"Loading Vieneu TTS Model on {device_name}...")
    from vieneu import Vieneu
    tts = Vieneu()
    print("✅ Vieneu TTS Model loaded successfully on GPU!")
except Exception as e:
    import traceback
    tts_init_error = traceback.format_exc()
    print(f"❌ Error loading Vieneu TTS model: {tts_init_error}")

# -------------------------------------------------------------
# 4. CLOUDFLARE R2 CLIENT SETUP
# -------------------------------------------------------------
R2_ACCOUNT_ID = os.getenv("R2_ACCOUNT_ID", "f06ba8171ed19ffa376ffc9cc8272797")
R2_ACCESS_KEY_ID = os.getenv("R2_ACCESS_KEY_ID", "e28aff4e61c385581358c1aed20dabec")
R2_SECRET_ACCESS_KEY = os.getenv("R2_SECRET_ACCESS_KEY", "c1af721539cf1427fd1368606effd8b12c799e10a22072d93d51bf2e16ec22ff")
R2_BUCKET_NAME = os.getenv("R2_BUCKET_NAME", "ai-studio-media")
R2_PUBLIC_DOMAIN = os.getenv("R2_PUBLIC_DOMAIN", "https://pub-4ca643f0ba0d43a783a68995813fef35.r2.dev").rstrip("/")

s3_client = None
if R2_ACCOUNT_ID and R2_ACCESS_KEY_ID and R2_SECRET_ACCESS_KEY:
    try:
        s3_client = boto3.client(
            "s3",
            endpoint_url=f"https://{R2_ACCOUNT_ID}.r2.cloudflarestorage.com",
            aws_access_key_id=R2_ACCESS_KEY_ID,
            aws_secret_access_key=R2_SECRET_ACCESS_KEY,
            region_name="auto",
        )
        print(f"✅ Cloudflare R2 connected to bucket: {R2_BUCKET_NAME}")
    except Exception as e:
        print(f"⚠️ Cloudflare R2 connection warning: {e}")

def download_asset(url: str, dest_path: str):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    }
    resp = requests.get(url, headers=headers, stream=True, timeout=60)
    resp.raise_for_status()
    with open(dest_path, 'wb') as out_file:
        for chunk in resp.iter_content(chunk_size=1024 * 1024):
            if chunk:
                out_file.write(chunk)
    return dest_path

# -------------------------------------------------------------
# 5. TTS ENGINE
# -------------------------------------------------------------
REF_AUDIO_CACHE = {}

def get_reference_audio(ref_url: str) -> str:
    if ref_url in REF_AUDIO_CACHE and os.path.exists(REF_AUDIO_CACHE[ref_url]):
        return REF_AUDIO_CACHE[ref_url]
    ext = ".wav" if ".wav" in ref_url.lower() else ".mp3"
    fd, tmp_path = tempfile.mkstemp(prefix="ref_", suffix=ext)
    os.close(fd)
    download_asset(ref_url, tmp_path)
    REF_AUDIO_CACHE[ref_url] = tmp_path
    return tmp_path

class TTSPayload(BaseModel):
    text: str
    voice: str = "Minh Đức"
    ref_audio_url: Optional[str] = None
    speed: Optional[float] = 1.0

def process_tts(payload: TTSPayload) -> dict:
    if tts is None:
        raise HTTPException(status_code=500, detail=f"TTS engine not initialized: {tts_init_error}")

    text = payload.text.strip()
    voice = payload.voice.strip()
    ref_audio_url = payload.ref_audio_url

    if not text:
        raise HTTPException(status_code=400, detail="Missing 'text' input")

    start_time = time.time()
    temp_wav_path = None

    try:
        if ref_audio_url:
            local_ref = get_reference_audio(ref_audio_url)
            audio_array = tts.infer(text, ref_audio=local_ref, voice=voice)
        else:
            clean_voice = voice[7:] if voice.startswith("custom_") else voice
            audio_array = tts.infer(text, voice=clean_voice)

        fd, temp_wav_path = tempfile.mkstemp(prefix="tts_out_", suffix=".wav")
        os.close(fd)
        tts.save(audio_array, temp_wav_path)

        sample_rate = 48000
        duration = round(len(audio_array) / sample_rate, 2)
        inference_time = round(time.time() - start_time, 2)

        audio_url = None
        if s3_client:
            filename = f"gen_voice_{uuid.uuid4().hex[:12]}.wav"
            object_key = f"generated_voices/{filename}"
            s3_client.upload_file(
                temp_wav_path,
                R2_BUCKET_NAME,
                object_key,
                ExtraArgs={"ContentType": "audio/wav"},
            )
            audio_url = f"{R2_PUBLIC_DOMAIN}/{object_key}"

        return {
            "status": "success",
            "audio_url": audio_url,
            "duration": duration,
            "inference_time_sec": inference_time,
            "device": device_name,
        }
    finally:
        if temp_wav_path and os.path.exists(temp_wav_path):
            try:
                os.remove(temp_wav_path)
            except Exception:
                pass

# -------------------------------------------------------------
# 6. VIDEO RENDER ENGINE (FFmpeg NVENC)
# -------------------------------------------------------------
def format_ass_time(seconds: float) -> str:
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = int(seconds % 60)
    cs = int((seconds % 1) * 100)
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"

def word_weight(w: str) -> int:
    w_clean = w.strip()
    weight = len(w_clean)
    if w_clean.endswith(',') or w_clean.endswith(':'): weight += 4
    if w_clean.endswith('.') or w_clean.endswith('!') or w_clean.endswith('?'): weight += 6
    return weight

def probe_video_duration(fpath: str) -> float:
    try:
        p_cmd = [FFPROBE_BIN, '-v', 'error', '-show_entries', 'format=duration', '-of', 'default=noprint_wrappers=1:nokey=1', fpath]
        res = subprocess.run(p_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=True)
        d = float(res.stdout.strip())
        return d if d > 0 else 10.0
    except Exception:
        return 10.0

class RenderVideoPayload(BaseModel):
    video_urls: List[str]
    voice_url: str
    bg_music_url: Optional[str] = None
    title_text: Optional[str] = ""
    script_text: Optional[str] = ""
    ass_content: Optional[str] = None
    brand_name: Optional[str] = ""
    target_duration: Optional[float] = 0.0

def process_render_video(payload: RenderVideoPayload) -> dict:
    start_time = time.time()
    work_dir = tempfile.mkdtemp(prefix="render_")

    try:
        video_urls = payload.video_urls
        if not video_urls:
            raise HTTPException(status_code=400, detail="Missing 'video_urls'")

        voice_url = payload.voice_url
        if not voice_url:
            raise HTTPException(status_code=400, detail="Missing 'voice_url'")

        bg_music_url = payload.bg_music_url
        title_text = (payload.title_text or "").replace("'", "\\'").replace(":", "\\:")
        script_text = (payload.script_text or "").strip()
        ass_content = payload.ass_content
        brand_name = (payload.brand_name or "").upper().strip()
        target_duration = float(payload.target_duration or 0.0)

        # 1. Tải video nền
        local_video_paths = []
        for idx, v_url in enumerate(video_urls):
            v_ext = os.path.splitext(v_url.split("?")[0])[1] or ".mp4"
            dest = os.path.join(work_dir, f"bg_vid_{idx}{v_ext}")
            download_asset(v_url, dest)
            local_video_paths.append(dest)

        # 2. Tải giọng đọc
        v_ext = os.path.splitext(voice_url.split("?")[0])[1] or ".wav"
        local_voice_path = os.path.join(work_dir, f"voice{v_ext}")
        download_asset(voice_url, local_voice_path)

        # 3. Tải nhạc nền nếu có
        local_music_path = None
        if bg_music_url:
            m_ext = os.path.splitext(bg_music_url.split("?")[0])[1] or ".mp3"
            local_music_path = os.path.join(work_dir, f"music{m_ext}")
            download_asset(bg_music_url, local_music_path)

        # 4. Xác định duration
        if target_duration <= 0:
            target_duration = probe_video_duration(local_voice_path) + 1.0
        voice_duration = target_duration - 1.0 if target_duration > 1.0 else target_duration

        # 5. Brand Overlay Badge
        brand_img_path = None
        if brand_name:
            try:
                font_brand_path = get_font_file("BeVietnamPro-Black.ttf")
                font_brand = ImageFont.truetype(font_brand_path, 55)
                tw = int(font_brand.getlength(brand_name))
                ascent, descent = font_brand.getmetrics()
                th = ascent + descent
                padding_x, padding_y = 30, 15
                bg_w, bg_h = tw + padding_x * 2, th + padding_y * 2
                img = Image.new('RGBA', (bg_w, bg_h), (0, 0, 0, 0))
                draw = ImageDraw.Draw(img)
                draw.rounded_rectangle([(0, 0), (bg_w, bg_h)], radius=10, fill=(0, 0, 0, 150))
                draw.text((bg_w / 2, bg_h / 2), brand_name, font=font_brand, fill=(255, 255, 255, 255), anchor="mm")
                brand_img_path = os.path.join(work_dir, "brand_badge.png")
                img.save(brand_img_path)
            except Exception as e:
                print(f"⚠️ Brand badge error: {e}")
                brand_img_path = None

        # 6. Phụ đề Karaoke ASS
        ass_path = os.path.join(work_dir, "subtitles.ass")
        font_ass_path = get_font_file("Oswald-Bold.ttf")
        font_ass_ffmpeg = font_ass_path.replace('\\', '/').replace(':', '\\:')
        fonts_dir_ffmpeg = FONTS_DIR.replace('\\', '/').replace(':', '\\:')

        if ass_content:
            with open(ass_path, "w", encoding="utf-8") as f:
                f.write(ass_content)
        elif script_text:
            raw_sentences = re.split(r'(?<=[.!?])\s+', script_text.strip())
            chunks = []
            for sent in raw_sentences:
                sent = sent.strip()
                if not sent: continue
                words = sent.split()
                if len(words) <= 8:
                    chunks.append(words)
                else:
                    num_chunks = math.ceil(len(words) / 8)
                    chunk_size = math.ceil(len(words) / num_chunks)
                    for i in range(num_chunks):
                        chunks.append(words[i*chunk_size : (i+1)*chunk_size])

            total_weight = sum(sum(word_weight(w) for w in c) for c in chunks)
            current_time = 1.3
            voice_duration_adj = voice_duration - 0.2 if voice_duration > 0.2 else voice_duration
            
            ass_header = """[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Oswald,125,&H0000FFFF,&H00FFFFFF,&H00000000,&H80000000,-1,0,0,0,100,100,0,0,1,6,6,5,40,40,0,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
            events = []
            line_spacing = 115
            for chunk_words in chunks:
                chunk_weight = sum(word_weight(w) for w in chunk_words)
                chunk_dur = (chunk_weight / total_weight) * voice_duration_adj if total_weight > 0 else 0
                start_time_str = format_ass_time(current_time)
                end_time_str = format_ass_time(current_time + chunk_dur)
                
                lines = [chunk_words[i:i+4] for i in range(0, len(chunk_words), 4)]
                block_height = len(lines) * line_spacing
                start_y = int(960 - (block_height / 2) + (line_spacing / 2))
                accumulated_cs = 0
                for line_idx, line_words in enumerate(lines):
                    line_y = start_y + line_idx * line_spacing
                    karaoke_text = f"{{\\pos(540,{line_y})}}"
                    if accumulated_cs > 0:
                        karaoke_text += f"{{\\k{accumulated_cs}}}"
                    for i, w in enumerate(line_words):
                        w_w = word_weight(w)
                        w_dur = (w_w / chunk_weight) * chunk_dur if chunk_weight > 0 else 0
                        w_cs = int(w_dur * 100)
                        if i > 0: karaoke_text += " "
                        karaoke_text += f"{{\\k{w_cs}}}{w}"
                        accumulated_cs += w_cs
                    events.append(f"Dialogue: 0,{start_time_str},{end_time_str},Default,,0,0,0,,{karaoke_text}")
                current_time += chunk_dur

            with open(ass_path, "w", encoding="utf-8") as f:
                f.write(ass_header + "\n".join(events) + "\n")

        # 7. Xây dựng lệnh FFmpeg
        command = [FFMPEG_BIN, '-y']
        filter_parts = []
        num_videos = len(local_video_paths)

        if num_videos == 1:
            command.extend(['-stream_loop', '-1', '-i', local_video_paths[0]])
            num_video_inputs = 1
            filter_parts.append("[0:v]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1/1,fps=30[base_vid]")
        else:
            durations = [probe_video_duration(vp) for vp in local_video_paths]
            segments = []
            cur_bg_duration = 0.0
            playheads = [0.0] * num_videos
            v_idx = 0
            while cur_bg_duration < target_duration:
                v_path = local_video_paths[v_idx]
                v_dur = durations[v_idx]
                seg_dur = min(10.0, v_dur) if v_dur > 0 else 10.0
                ss = playheads[v_idx] % v_dur if v_dur > 0 else 0.0
                segments.append({'path': v_path, 'ss': ss, 'dur': seg_dur})
                playheads[v_idx] += seg_dur
                cur_bg_duration += seg_dur
                v_idx = (v_idx + 1) % num_videos

            for seg in segments:
                command.extend(['-stream_loop', '-1', '-ss', f"{seg['ss']:.2f}", '-t', f"{seg['dur']:.2f}", '-i', seg['path']])
            num_video_inputs = len(segments)

            for i in range(num_video_inputs):
                filter_parts.append(f"[{i}:v]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1/1,fps=30,setpts=PTS-STARTPTS[v{i}]")
            concat_inputs = "".join([f"[v{i}]" for i in range(num_video_inputs)])
            filter_parts.append(f"{concat_inputs}concat=n={num_video_inputs}:v=1:a=0[base_vid]")

        command.extend(['-i', local_voice_path])
        idx_voice = num_video_inputs

        idx_music = -1
        if local_music_path and os.path.exists(local_music_path):
            command.extend(['-stream_loop', '-1', '-i', local_music_path])
            idx_music = idx_voice + 1

        idx_brand = -1
        if brand_img_path and os.path.exists(brand_img_path):
            command.extend(['-i', brand_img_path])
            idx_brand = idx_music + 1 if idx_music != -1 else idx_voice + 1

        if idx_brand != -1:
            filter_parts.append(f"[base_vid][{idx_brand}:v]overlay=(W-w)/2:300[vid_branded]")
            v_curr = "[vid_branded]"
        else:
            v_curr = "[base_vid]"

        if title_text:
            v_filter = f"{v_curr}drawtext=fontfile='{font_ass_ffmpeg}':text='{title_text}':fontcolor=yellow:fontsize=95:x=(w-text_w)/2:y=200:bordercolor=black:borderw=8:enable='between(t,0,1)'"
        else:
            v_filter = f"{v_curr}null"

        if os.path.exists(ass_path):
            ass_path_ffmpeg = ass_path.replace('\\', '/').replace(':', '\\:')
            v_filter += f",ass=filename='{ass_path_ffmpeg}':fontsdir='{fonts_dir_ffmpeg}'[vout]"
        else:
            v_filter += "[vout]"
        filter_parts.append(v_filter)

        fade_start = target_duration - 2.0 if target_duration > 2.0 else 0
        if idx_music != -1:
            filter_parts.append(f"[{idx_music}:a]volume=0.15,afade=t=out:st={fade_start}:d=2[bgm];[{idx_voice}:a]adelay=1000:all=1,volume=3.0[voice];[voice][bgm]amix=inputs=2:duration=first,volume=2.0[aout]")
        else:
            filter_parts.append(f"[{idx_voice}:a]adelay=1000:all=1,volume=3.5[aout]")

        filter_complex = ";".join(filter_parts)
        output_mp4_path = os.path.join(work_dir, "output.mp4")

        command.extend([
            '-filter_complex', filter_complex,
            '-map', '[vout]', '-map', '[aout]',
            *ENCODER_FLAGS,
            '-c:a', 'aac', '-b:a', '128k',
            '-t', str(target_duration),
            output_mp4_path
        ])

        print(f"🎬 [Video Render] Bắt đầu FFmpeg GPU NVENC (duration: {target_duration}s)...")
        render_start = time.time()
        p = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if p.returncode != 0:
            print(f"❌ FFmpeg Error:\n{p.stderr}")
            raise HTTPException(status_code=500, detail=f"FFmpeg render failed: {p.stderr[-500:]}")

        render_elapsed = round(time.time() - render_start, 2)
        print(f"⚡ [Video Render] Hoàn tất render trong {render_elapsed} giây!")

        # 8. Thumbnail
        thumb_jpg_path = os.path.join(work_dir, "thumb.jpg")
        subprocess.run([
            FFMPEG_BIN, "-y", "-ss", "00:00:01.000",
            "-i", output_mp4_path,
            "-vframes", "1", "-q:v", "2",
            thumb_jpg_path
        ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        # 9. Upload R2
        video_url = None
        thumb_url = None
        if s3_client:
            uid_str = uuid.uuid4().hex[:12]
            vid_key = f"generated_videos/video_{uid_str}.mp4"
            thumb_key = f"generated_videos/thumb_{uid_str}.jpg"

            s3_client.upload_file(output_mp4_path, R2_BUCKET_NAME, vid_key, ExtraArgs={"ContentType": "video/mp4"})
            video_url = f"{R2_PUBLIC_DOMAIN}/{vid_key}"

            if os.path.exists(thumb_jpg_path):
                s3_client.upload_file(thumb_jpg_path, R2_BUCKET_NAME, thumb_key, ExtraArgs={"ContentType": "image/jpeg"})
                thumb_url = f"{R2_PUBLIC_DOMAIN}/{thumb_key}"

        return {
            "status": "success",
            "video_url": video_url,
            "thumbnail_url": thumb_url,
            "duration": target_duration,
            "render_time_sec": render_elapsed,
            "total_elapsed_sec": round(time.time() - start_time, 2),
            "device": f"{device_name} (NVENC Accelerated)" if "h264_nvenc" in ENCODER_FLAGS else device_name
        }
    finally:
        shutil.rmtree(work_dir, ignore_errors=True)

# -------------------------------------------------------------
# 6B. LIST VIDEO RENDER ENGINE (Card Overlay + BGM + Video/Slideshow)
# -------------------------------------------------------------
class RenderListVideoPayload(BaseModel):
    video_urls: List[str] = []
    image_urls: List[str] = []
    bg_type: str = "video"  # "video" or "image"
    bg_music_url: Optional[str] = None
    top_text: str = ""
    script_content: str = ""
    brand_name: Optional[str] = ""
    brand_avatar_url: Optional[str] = None
    target_duration: float = 15.0

def _wrap_text_list(text: str, font, max_width: int, draw) -> list:
    all_lines = []
    for explicit_line in text.split('\n'):
        words = explicit_line.split()
        if not words:
            continue
        current = ""
        for word in words:
            test = (current + " " + word).strip()
            bbox = draw.textbbox((0, 0), test, font=font)
            if bbox[2] <= max_width:
                current = test
            else:
                if current:
                    all_lines.append(current)
                current = word
        if current:
            all_lines.append(current)
    return all_lines

def generate_list_card_image(
    title: str,
    items: list,
    brand_name: str,
    avatar_path: Optional[str],
    output_image_path: str,
    canvas_w: int = 1080,
    canvas_h: int = 1920,
) -> bool:
    try:
        font_black_path = get_font_file("BeVietnamPro-Black.ttf")
        font_bold_path = get_font_file("BeVietnamPro-Bold.ttf")
        if not os.path.exists(font_bold_path):
            font_bold_path = font_black_path

        num_items = len(items)
        if num_items >= 7:
            ITEM_SIZE, TITLE_SIZE, ITEM_GAP, CARD_PAD_Y = 40, 50, 18, 46
        elif num_items == 6:
            ITEM_SIZE, TITLE_SIZE, ITEM_GAP, CARD_PAD_Y = 43, 54, 20, 50
        elif num_items == 5:
            ITEM_SIZE, TITLE_SIZE, ITEM_GAP, CARD_PAD_Y = 46, 56, 24, 55
        else:
            ITEM_SIZE, TITLE_SIZE, ITEM_GAP, CARD_PAD_Y = 48, 58, 26, 58

        BRAND_SIZE = 52
        NUM_SIZE = ITEM_SIZE

        brand_font = ImageFont.truetype(font_black_path, BRAND_SIZE)
        title_font = ImageFont.truetype(font_black_path, TITLE_SIZE)
        item_font  = ImageFont.truetype(font_bold_path,  ITEM_SIZE)
        num_font   = ImageFont.truetype(font_black_path, NUM_SIZE)

        TITLE_LINE_H = int(TITLE_SIZE * 1.32)
        ITEM_LINE_H  = int(ITEM_SIZE * 1.35)

        overlay = Image.new("RGBA", (canvas_w, canvas_h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(overlay)

        CARD_X, CARD_W, CARD_PAD_X, CARD_Y, CARD_H = 70, 940, 55, 290, 1340

        av_img_resized = None
        ax, ay = canvas_w, canvas_h
        has_avatar = False

        if avatar_path and os.path.exists(avatar_path):
            try:
                avatar_raw = Image.open(avatar_path).convert("RGBA")
                av_bbox = avatar_raw.getbbox()
                if av_bbox:
                    avatar_raw = avatar_raw.crop(av_bbox)
                raw_w, raw_h = avatar_raw.size
                if raw_w > 0 and raw_h > 0:
                    AVATAR_W = 350
                    scale = AVATAR_W / raw_w
                    new_h = int(raw_h * scale)
                    if new_h > 580:
                        new_h = 580
                        AVATAR_W = int(raw_w * (new_h / raw_h))
                    av_img_resized = avatar_raw.resize((AVATAR_W, new_h), Image.LANCZOS)
                    ax = canvas_w - AVATAR_W - 25
                    ay = canvas_h - new_h
                    has_avatar = True
            except Exception as e:
                print(f"[Avatar Prep] Error: {e}")

        card_rect = [CARD_X, CARD_Y, CARD_X + CARD_W, CARD_Y + CARD_H]
        draw.rounded_rectangle(card_rect, radius=28, fill=(255, 255, 255, 204))

        # Brand name
        brand_y = 150
        brand_text = (brand_name or "THƯƠNG HIỆU").upper()
        brand_bbox = draw.textbbox((0, 0), brand_text, font=brand_font)
        brand_x = (canvas_w - (brand_bbox[2] - brand_bbox[0])) // 2

        outline_color = (0, 0, 0, 200)
        for dx in [-2, 0, 2]:
            for dy in [-2, 0, 2]:
                draw.text((brand_x + dx, brand_y + dy), brand_text, font=brand_font, fill=outline_color)
        draw.text((brand_x + 4, brand_y + 4), brand_text, font=brand_font, fill=(0, 0, 0, 150))
        draw.text((brand_x, brand_y), brand_text, font=brand_font, fill=(255, 255, 255, 255))

        # Title
        RED   = (220, 38, 38, 255)
        BLACK = (30, 30, 30, 255)

        title_clean = re.sub(r'[/\n]+', '\n', (title or "").upper()).strip()
        title_lines = _wrap_text_list(title_clean, title_font, CARD_W - CARD_PAD_X * 2, draw)

        ty = CARD_Y + CARD_PAD_Y
        for idx, line in enumerate(title_lines):
            color = RED if idx == 0 else BLACK
            line_bbox = draw.textbbox((0, 0), line, font=title_font)
            line_w = line_bbox[2] - line_bbox[0]
            lx = CARD_X + (CARD_W - line_w) // 2
            draw.text((lx, ty), line, font=title_font, fill=color)
            ty += TITLE_LINE_H

        ty += 22

        full_text_w = CARD_W - CARD_PAD_X * 2
        avoid_avatar_w = max(420, (ax - (CARD_X + CARD_PAD_X)) - 35) if has_avatar else full_text_w

        def get_max_w_at_y(curr_y):
            if has_avatar and curr_y >= ay - 25:
                return avoid_avatar_w
            return full_text_w

        num_sample = draw.textbbox((0, 0), "9. ", font=num_font)
        num_w = num_sample[2] - num_sample[0]

        for i, item in enumerate(items):
            clean = re.sub(r'^\d+[\.\)]\s*', '', item).strip()
            num = i + 1
            words = clean.split()

            curr_words = []
            curr_line_y = ty
            item_lines = []
            is_first_line = True

            for w in words:
                test_words = curr_words + [w]
                test_clean = ' '.join(tw.replace('**', '') for tw in test_words)
                tb = draw.textbbox((0, 0), test_clean, font=item_font)
                test_w = tb[2] - tb[0]
                allowed_w = get_max_w_at_y(curr_line_y) - (num_w if is_first_line else 0)

                if test_w <= allowed_w:
                    curr_words.append(w)
                else:
                    if curr_words:
                        item_lines.append((' '.join(curr_words), is_first_line, curr_line_y))
                        curr_line_y += ITEM_LINE_H
                        is_first_line = False
                    curr_words = [w]

            if curr_words:
                item_lines.append((' '.join(curr_words), is_first_line, curr_line_y))
                curr_line_y += ITEM_LINE_H

            for line_str, first_flag, ly in item_lines:
                ix = CARD_X + CARD_PAD_X
                if first_flag:
                    draw.text((ix, ly), f"{num}. ", font=num_font, fill=RED)
                    ix += num_w
                else:
                    ix += num_w

                words_in_line = line_str.split()
                is_red = False
                for wi, w in enumerate(words_in_line):
                    disp = w
                    turn_off = False
                    if disp.startswith('**'):
                        is_red = True
                        disp = disp[2:]
                    if '**' in disp:
                        disp = disp.replace('**', '')
                        turn_off = True

                    color = RED if is_red else BLACK
                    if wi < len(words_in_line) - 1:
                        disp += " "

                    draw.text((ix, ly), disp, font=item_font, fill=color)
                    wb = draw.textbbox((ix, ly), disp, font=item_font)
                    ix = wb[2]

                    if turn_off:
                        is_red = False

            ty = curr_line_y + ITEM_GAP

        if has_avatar and av_img_resized is not None:
            overlay.paste(av_img_resized, (ax, ay), av_img_resized)

        overlay.save(output_image_path, "PNG")
        return True
    except Exception as e:
        print(f"[generate_list_card_image] Error: {e}")
        return False

def create_slideshow_from_images(image_paths: list, output_path: str, target_duration: float = 15.0) -> bool:
    if not image_paths:
        return False
    try:
        if len(image_paths) == 1:
            cmd = [
                FFMPEG_BIN, "-y", "-loop", "1", "-t", str(target_duration), "-i", image_paths[0],
                "-vf", "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1",
                *ENCODER_FLAGS, "-pix_fmt", "yuv420p", output_path
            ]
            subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
            return True
        else:
            duration_per_img = target_duration / len(image_paths)
            cmd = [FFMPEG_BIN, "-y"]
            filter_complex = ""
            concat_inputs = ""
            for i, img in enumerate(image_paths):
                cmd.extend(["-loop", "1", "-t", str(duration_per_img), "-i", img])
                filter_complex += f"[{i}:v]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1[v{i}]; "
                concat_inputs += f"[v{i}]"
            filter_complex += f"{concat_inputs}concat=n={len(image_paths)}:v=1:a=0[outv]"
            cmd.extend([
                "-filter_complex", filter_complex,
                "-map", "[outv]",
                *ENCODER_FLAGS, "-pix_fmt", "yuv420p",
                output_path
            ])
            subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
            return True
    except Exception as e:
        print(f"Slideshow error: {e}")
        return False

def process_render_list_video(payload: RenderListVideoPayload) -> Dict[str, Any]:
    start_time = time.time()
    work_dir = tempfile.mkdtemp(prefix="vast_list_render_")

    try:
        target_duration = max(5.0, float(payload.target_duration or 15.0))
        bg_type = payload.bg_type or "video"

        # 1. Download Music
        local_music = None
        if payload.bg_music_url:
            local_music = download_file(payload.bg_music_url, work_dir, "music.mp3")

        # 2. Download Avatar
        local_avatar = None
        if payload.brand_avatar_url:
            local_avatar = download_file(payload.brand_avatar_url, work_dir, "avatar.png")

        # 3. Background Videos or Images
        video_paths = []
        if bg_type == "image":
            image_urls = payload.image_urls or payload.video_urls
            downloaded_imgs = []
            for idx, img_u in enumerate(image_urls[:6]):
                p = download_file(img_u, work_dir, f"bg_img_{idx}.jpg")
                if p and os.path.exists(p):
                    downloaded_imgs.append(p)
            if not downloaded_imgs:
                raise HTTPException(status_code=400, detail="No valid background images found")
            slideshow_path = os.path.join(work_dir, "slideshow.mp4")
            if not create_slideshow_from_images(downloaded_imgs, slideshow_path, target_duration):
                raise HTTPException(status_code=500, detail="Failed to create slideshow from images")
            video_paths.append(slideshow_path)
        else:
            downloaded_vids = []
            for idx, vid_u in enumerate(payload.video_urls[:10]):
                p = download_file(vid_u, work_dir, f"bg_vid_{idx}.mp4")
                if p and os.path.exists(p):
                    downloaded_vids.append(p)
            if not downloaded_vids:
                raise HTTPException(status_code=400, detail="No valid background videos found")

            # Accumulate videos to cover duration
            curr_dur = 0.0
            attempts = 0
            while curr_dur < target_duration and attempts < 15:
                attempts += 1
                v_choice = random.choice(downloaded_vids)
                video_paths.append(v_choice)
                curr_dur += probe_video_duration(v_choice)

        # 4. Generate Card Overlay
        items = [line.strip() for line in (payload.script_content or "").split("\n") if line.strip()]
        card_image_path = os.path.join(work_dir, "card_overlay.png")
        if not generate_list_card_image(
            title=payload.top_text,
            items=items,
            brand_name=payload.brand_name or "THƯƠNG HIỆU",
            avatar_path=local_avatar,
            output_image_path=card_image_path
        ):
            raise HTTPException(status_code=500, detail="Failed to generate list card overlay image")

        # 5. FFmpeg Composition
        command = [FFMPEG_BIN, "-y"]
        for vp in video_paths:
            command.extend(["-i", vp])

        num_videos = len(video_paths)
        command.extend(["-i", card_image_path])
        idx_card = num_videos

        has_music = bool(local_music and os.path.exists(local_music))
        if has_music:
            command.extend(["-i", local_music])
            idx_music = num_videos + 1

        filter_parts = []
        if num_videos == 1:
            filter_parts.append("[0:v]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1/1,fps=30[base_vid]")
        else:
            for i in range(num_videos):
                filter_parts.append(f"[{i}:v]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1/1,fps=30[v{i}]")
            concat_inputs = "".join(f"[v{i}]" for i in range(num_videos))
            filter_parts.append(f"{concat_inputs}concat=n={num_videos}:v=1:a=0[base_vid]")

        filter_parts.append(
            f"[{idx_card}:v]scale=1080:1920[card];"
            f"[base_vid][card]overlay=0:0[vout]"
        )

        audio_map = []
        if has_music:
            filter_parts.append(f"[{idx_music}:a]volume=1.0[aout]")
            audio_map = ["-map", "[aout]"]

        output_mp4_path = os.path.join(work_dir, "list_video_output.mp4")
        command.extend([
            "-filter_complex", ";".join(filter_parts),
            "-map", "[vout]",
            *audio_map,
            *ENCODER_FLAGS,
            "-c:a", "aac", "-b:a", "128k",
            "-t", str(target_duration),
            output_mp4_path
        ])

        print(f"🎬 [List Video Render] Bắt đầu FFmpeg (duration: {target_duration}s)...")
        render_start = time.time()
        p = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if p.returncode != 0:
            print(f"❌ FFmpeg Error:\n{p.stderr}")
            raise HTTPException(status_code=500, detail=f"FFmpeg render failed: {p.stderr[-500:]}")

        render_elapsed = round(time.time() - render_start, 2)
        print(f"⚡ [List Video Render] Render xong trong {render_elapsed} giây!")

        # 6. Thumbnail
        thumb_jpg_path = os.path.join(work_dir, "thumb.jpg")
        subprocess.run([
            FFMPEG_BIN, "-y", "-ss", "00:00:00.100",
            "-i", output_mp4_path,
            "-vframes", "1", "-q:v", "2",
            thumb_jpg_path
        ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        # 7. Upload to Cloudflare R2
        video_url = None
        thumb_url = None
        if s3_client:
            uid_str = uuid.uuid4().hex[:12]
            vid_key = f"list_videos/render_{uid_str}.mp4"
            thumb_key = f"list_videos/thumb_{uid_str}.jpg"

            s3_client.upload_file(output_mp4_path, R2_BUCKET_NAME, vid_key, ExtraArgs={"ContentType": "video/mp4"})
            video_url = f"{R2_PUBLIC_DOMAIN}/{vid_key}"

            if os.path.exists(thumb_jpg_path):
                s3_client.upload_file(thumb_jpg_path, R2_BUCKET_NAME, thumb_key, ExtraArgs={"ContentType": "image/jpeg"})
                thumb_url = f"{R2_PUBLIC_DOMAIN}/{thumb_key}"

        return {
            "status": "success",
            "video_url": video_url,
            "thumbnail_url": thumb_url,
            "duration": target_duration,
            "render_time_sec": render_elapsed,
            "total_elapsed_sec": round(time.time() - start_time, 2),
            "device": f"{device_name} (NVENC Accelerated)" if "h264_nvenc" in ENCODER_FLAGS else device_name
        }
    finally:
        shutil.rmtree(work_dir, ignore_errors=True)

# -------------------------------------------------------------
# 7. FASTAPI ROUTES
# -------------------------------------------------------------
@app.get("/")
@app.get("/health")
def health_check():
    return {
        "status": "online",
        "service": "vast-worker-gpu",
        "device": device_name,
        "nvenc": "h264_nvenc" in ENCODER_FLAGS,
        "model_loaded": tts is not None,
    }

@app.post("/api/tts")
@app.post("/tts")
def tts_endpoint(payload: TTSPayload):
    return process_tts(payload)

@app.post("/api/render_video")
@app.post("/render_video")
def render_video_endpoint(payload: RenderVideoPayload):
    return process_render_video(payload)

@app.post("/api/render_list_video")
@app.post("/render_list_video")
def render_list_video_endpoint(payload: RenderListVideoPayload):
    return process_render_list_video(payload)

@app.post("/runsync")
def runsync_compatibility(payload: Dict[str, Any]):
    inp = payload.get("input", {})
    task = inp.get("task", "tts")
    if task == "render_list_video":
        res = process_render_list_video(RenderListVideoPayload(**inp))
    elif task in ["render_video", "render_voiceai_video"]:
        res = process_render_video(RenderVideoPayload(**inp))
    else:
        res = process_tts(TTSPayload(**inp))
    return {"status": "COMPLETED", "output": res}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
