# -*- coding: utf-8 -*-
"""
VAST.AI GPU CLIENT
Module gọi API trực tiếp sang máy chủ Vast.ai GPU Dedicated Pod (24/7, 0s Cold Start).
Được tích hợp vào api-text-to-speech và api-voiceai-video.
"""

import os
import time
import requests
from typing import Optional, Dict, Any, List

VAST_GPU_URL = (
    os.environ.get("VAST_GPU_URL")
    or os.environ.get("VASTAI_GPU_URL")
    or "https://weed-absolute-trips-signals.trycloudflare.com"
).rstrip("/")

def is_vast_gpu_enabled() -> bool:
    """Kiểm tra xem Vast.ai GPU đã được kích hoạt hay chưa"""
    return bool(VAST_GPU_URL)

def check_vast_gpu_health() -> Dict[str, Any]:
    """Kiểm tra tình trạng sức khỏe của Vast.ai GPU"""
    if not is_vast_gpu_enabled():
        return {"status": "disabled", "error": "VAST_GPU_URL is not set"}
    try:
        res = requests.get(f"{VAST_GPU_URL}/health", timeout=5)
        if res.status_code == 200:
            return res.json()
        return {"status": "unhealthy", "status_code": res.status_code}
    except Exception as e:
        return {"status": "offline", "error": str(e)}

def vast_tts_synthesize(
    text: str,
    voice: str = "Minh Đức",
    ref_audio_url: Optional[str] = None,
    speed: float = 1.0,
    timeout: int = 45
) -> Dict[str, Any]:
    """
    Gửi văn bản sang Vast.ai RTX 3060 để tổng hợp giọng nói tiếng Việt tức thì (~1-2s).
    Trả về dict: { "audio_url": str, "duration": float, "audio_bytes": bytes, "inference_time_sec": float }
    """
    if not is_vast_gpu_enabled():
        raise RuntimeError("Vast.ai GPU chưa được cấu hình VAST_GPU_URL")

    url = f"{VAST_GPU_URL}/api/tts"
    payload = {
        "text": text,
        "voice": voice,
        "ref_audio_url": ref_audio_url,
        "speed": speed
    }

    start_time = time.time()
    resp = requests.post(url, json=payload, timeout=timeout)
    if resp.status_code != 200:
        raise RuntimeError(f"Vast.ai GPU TTS Error ({resp.status_code}): {resp.text}")

    data = resp.json()
    audio_url = data.get("audio_url")
    duration = data.get("duration", 0.0)
    inference_time = data.get("inference_time_sec", round(time.time() - start_time, 2))

    audio_bytes = b""
    if audio_url:
        try:
            dl = requests.get(audio_url, timeout=10)
            if dl.status_code == 200:
                audio_bytes = dl.content
        except Exception:
            pass

    return {
        "status": "success",
        "audio_url": audio_url,
        "duration": duration,
        "audio_bytes": audio_bytes,
        "inference_time_sec": inference_time,
        "device": data.get("device", "Vast.ai RTX 3060")
    }

def vast_render_video(
    video_urls: List[str],
    voice_url: str,
    bg_music_url: Optional[str] = None,
    title_text: Optional[str] = "",
    script_text: Optional[str] = "",
    ass_content: Optional[str] = None,
    brand_name: Optional[str] = "",
    target_duration: Optional[float] = 0.0,
    timeout: int = 180
) -> Dict[str, Any]:
    """
    Gửi payload sang Vast.ai RTX 3060 để render video FFmpeg NVENC siêu tốc (~3-5s).
    Trả về dict: { "video_url": str, "thumbnail_url": str, "duration": float, "render_time_sec": float }
    """
    if not is_vast_gpu_enabled():
        raise RuntimeError("Vast.ai GPU chưa được cấu hình VAST_GPU_URL")

    url = f"{VAST_GPU_URL}/api/render_video"
    payload = {
        "video_urls": video_urls,
        "voice_url": voice_url,
        "bg_music_url": bg_music_url,
        "title_text": title_text,
        "script_text": script_text,
        "ass_content": ass_content,
        "brand_name": brand_name,
        "target_duration": target_duration
    }

    start_time = time.time()
    resp = requests.post(url, json=payload, timeout=timeout)
    if resp.status_code != 200:
        raise RuntimeError(f"Vast.ai GPU Video Render Error ({resp.status_code}): {resp.text}")

    data = resp.json()
    return {
        "status": "success",
        "video_url": data.get("video_url"),
        "thumbnail_url": data.get("thumbnail_url"),
        "duration": data.get("duration", 0.0),
        "render_time_sec": data.get("render_time_sec", round(time.time() - start_time, 2)),
        "device": data.get("device", "Vast.ai RTX 3060 (NVENC)")
    }

def vast_render_list_video(
    video_urls: List[str] = [],
    image_urls: List[str] = [],
    bg_type: str = "video",
    bg_music_url: Optional[str] = None,
    top_text: str = "",
    script_content: str = "",
    brand_name: Optional[str] = "",
    brand_avatar_url: Optional[str] = None,
    target_duration: float = 15.0,
    timeout: int = 180
) -> Dict[str, Any]:
    """
    Gửi yêu cầu render Video Danh Sách sang Vast.ai Dedicated Worker để xử lý siêu tốc (~2-3s).
    Trả về dict: { "status": "success", "video_url": str, "thumbnail_url": str, "duration": float, "render_time_sec": float }
    """
    if not is_vast_gpu_enabled():
        raise RuntimeError("Vast.ai GPU chưa được cấu hình VAST_GPU_URL")

    url = f"{VAST_GPU_URL}/api/render_list_video"
    payload = {
        "video_urls": video_urls,
        "image_urls": image_urls,
        "bg_type": bg_type,
        "bg_music_url": bg_music_url,
        "top_text": top_text,
        "script_content": script_content,
        "brand_name": brand_name,
        "brand_avatar_url": brand_avatar_url,
        "target_duration": target_duration
    }

    start_time = time.time()
    resp = requests.post(url, json=payload, timeout=timeout)
    if resp.status_code != 200:
        raise RuntimeError(f"Vast.ai GPU List Video Render Error ({resp.status_code}): {resp.text}")

    data = resp.json()
    return {
        "status": "success",
        "video_url": data.get("video_url"),
        "thumbnail_url": data.get("thumbnail_url"),
        "duration": data.get("duration", target_duration),
        "render_time_sec": data.get("render_time_sec", round(time.time() - start_time, 2)),
        "device": data.get("device", "Vast.ai Worker")
    }

